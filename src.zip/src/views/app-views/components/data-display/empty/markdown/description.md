---
order: 4
title:
  zh-CN: 无描述
  en-US: No description
---

## zh-CN

无描述展示。

## en-US

Simplest Usage with no description.

```jsx
import { Empty } from 'antd';

ReactDOM.render(<Empty description={false} />, mountNode);
```
