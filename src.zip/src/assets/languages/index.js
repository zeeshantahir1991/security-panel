import en from './en'
export const AppLanguages = {
    en
} 